<?php

/**
 * @author 李雪莲 <lixuelianlk@163.com>
 * 后台 登录
 * 2015-02-07 15:14
 */
class IndexAction extends CommonAction {

    public function index() {
        parent::_initalize();
        $systemConfig = $this->systemConfig;
        $this->assign("systemConfig", $systemConfig);
        var_dump($systemConfig);
        $this->display();
    }

    public function login() {
        $systemConfig = include WEB_ROOT . 'Common/systemConfig.php';
        if(IS_POST){
            echo "dds";exit;
            
            
        }
        $this->assign("systemConfig", $systemConfig);
        $this->display();
    }

    /**
     * 验证码
     */
    public function verify_code() {
        $w = isset($_GET['w']) ? (int) $_GET['w'] : 50;
        $h = isset($_GET['h']) ? (int) $_GET['h'] : 30;
        import("ORG.Util.Image");
        Image::buildImageVerify(4, 1, 'png', $w, $h);
    }
    /**
     * 验证验证码是否正确
     */
    public function check_code(){
        header("Content-Type:text/html; charset=utf-8");
        header('Content-Type:application/json; charset=utf-8');
        $verify=session("verify");
        $post_val=trim($_POST['post_val']);
        $post_val=  md5($post_val);
        if($verify==$post_val){
            $arr=array("msg"=>"输入正确","code"=>1);
        }else{
            $arr=array("msg"=>"输入错误","code"=>0);
        }
        echo json_encode($arr);
    }

}
