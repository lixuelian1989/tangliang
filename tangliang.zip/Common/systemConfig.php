<?php

return array(
    'SITE_INFO' => array(
        'name' => '唐亮工长俱乐部',
        'keyword' => '唐亮工长俱乐部', 
        'description' => '唐亮工长俱乐部',
        'version' => '唐亮工长俱乐部 1.0', 
        
        
        'name_cms' => '唐亮工长俱乐部_管理系统',
        'keyword_cms' => '唐亮工长俱乐部_管理系统', 
        'description_cms' => '唐亮工长俱乐部_管理系统',
        'version_cms' => '唐亮工长俱乐部_管理系统 1.0', 
        
        
        
        'LANG_SWITCH_ON' => 1, 
        
        'url' => 'http://localhost/tangliang/',
        ),
    
    
    'LISTNUM' => array('DEFAULT_THEME' => 'default', 'prolist' => 12, 'newslist' => 12, 'noIndColor' => '#4f6128',),
    'TOKEN' => array('false_static' => 1, 'mess_on' => 1, 'admin_marked' => '', 'admin_timeout' => 3600,
        'member_marked' => '', 'member_timeout' => 3600,
        ),
    'WEB_ROOT' => 'http://localhost/tangliang/',
    'AUTH_CODE' => 'PnopdT', 
    'ADMIN_AUTH_KEY' => 'lixuelianlk@163.com', 
    'DB_HOST' => '127.0.0.1', 
    'DB_NAME' => 'tangliangdbs', 
    'DB_USER' => 'root',
    'DB_PWD' => '', 
    'DB_PORT' => '3306', 
    'DB_PREFIX' => 't_', 
    'webPath' => '/',
    );
?>
