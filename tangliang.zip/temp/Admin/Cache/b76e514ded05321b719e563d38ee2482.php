<?php if (!defined('THINK_PATH')) exit();?><!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <title><?php echo ($systemConfig["SITE_INFO"]["name_cms"]); ?></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="<?php echo ($systemConfig["SITE_INFO"]["description_cms"]); ?>" />
        <meta name="keywords" content="<?php echo ($systemConfig["SITE_INFO"]["keyword_cms"]); ?>" />
        <script src="<?php echo ($systemConfig["WEB_ROOT"]); ?>Public/js/jquery.js"></script>
        <script src="<?php echo ($systemConfig["WEB_ROOT"]); ?>Public/js/jquery.validate.js"></script>

    </head>
    <body>
        <div>登录</div>
        <form name="form_login" id="form_login" action="" method="post" >
            <div>账户:<input type="text" name="name" id="name" value="" class="required" /></div>
            <div>密码:<input type="password" name="pwd" id="pwd" value="" class="required" /></div>
            <div>验证码:<input class="input required" id="verify_code" name="verify_code" type="text" style="width:100px;" /> <img src="<?php echo U('Index/verify_code');?>"  title="看不清？单击此处刷新" onclick="this.src += '?rand=' + Math.random();"  style="cursor: pointer; vertical-align: middle;"/>
            </div>
            <div>
                <input type="submit" id="sub" value="提交"  />
            </div>
        </form>

    </body>
</html>
<script>
    $(document).ready(function() {
        $("#form_login").validate({
            rules:{
                name:{required:true,},
                pwd:{required:true,},
                verify_code:{required:true,}
            },
            messages:{
                name:{required:"请输入用户名"},
                pwd:{required:"请输入密码"},
                verify_code:{required:"请输入验证码"}
            }
        });
        $("#verify_code").keyup(function() {
            $.ajax({
                url: "<?php echo U('Index/check_code');?>",
                data: "post_val=" + $(this).val(),
                type: "POST",
                cache: false,
                dataType: "JSON",
                success: function(msg) {
                    if (msg.code == 0) {
                        $("#sub").attr("disabled", true);
                    } else {
                        $("#sub").attr("disabled", false);
                    }
                }
            });
        });
    })
</script>